DELETE FROM land_covers WHERE sheet_id = 'SD6441' AND parcel_id = '1283' AND land_cover_class_code = '131' AND is_linear_feature = false;
DELETE FROM land_covers WHERE sheet_id = 'SD6441' AND parcel_id = '1283' AND land_cover_class_code = '643' AND is_linear_feature = false;
