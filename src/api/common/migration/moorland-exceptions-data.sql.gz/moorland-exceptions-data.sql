TRUNCATE TABLE public.moorland_exceptions;

INSERT INTO public.moorland_exceptions(parcel_id, sheet_id, ref_code)
VALUES ('7268', 'SD6743', 'M');
