TRUNCATE TABLE public.actions;

INSERT INTO actions (version, enabled, display, start_date, duration_years, code, description, application_unit_of_measurement, payment, land_cover_class_codes, rules, last_updated) 
VALUES
(
    1, 
    TRUE, 
    TRUE, 
    '2025-01-01',
    3, 
    'CMOR1', 
    'CMOR1: Assess moorland and produce a written record', 
    'ha',
    '{
        "ratePerUnitGbp": 10.6,
        "ratePerAgreementPerYearGbp": 272
    }',
    '[
        "130",
        "240",
        "250",
        "270",
        "280",
        "300",
        "330",
        "580",
        "590",
        "620",
        "640",
        "650"
    ]',
    '[
        {
            "name": "parcel-has-intersection-with-data-layer",
            "config": {
            "layerName": "moorland",
            "minimumIntersectionPercent": 50,
            "tolerancePercent": 1
            }
        },
        {
            "name": "applied-for-total-available-area"
        }
    ]',
    now()
),(
    1, 
    TRUE, 
    TRUE, 
    '2025-01-01',
    3, 
    'UPL1',
    'UPL1: Moderate livestock grazing on moorland',
    'ha',
    '{
       "ratePerUnitGbp": 20
    }',
    '[
    "130",
    "240",
    "250",
    "270",
    "280",
    "300",
    "330",
    "580",
    "590",
    "620",
    "640",
    "650"
    ]',
    '[
        {
            "name": "parcel-has-intersection-with-data-layer",
            "config": {
            "layerName": "moorland",
            "minimumIntersectionPercent": 50,
            "tolerancePercent": 1
            }
        },
        {
            "name": "applied-for-total-available-area"
        }
    ]',
    now()
),
(
    1,
    TRUE,
    TRUE,
    '2025-01-01',
    3,
    'UPL2',
    'UPL2: Low livestock grazing on moorland',
    'ha',
    '{
    "ratePerUnitGbp": 53
    }',
    '[
    "130",
    "240",
    "250",
    "270",
    "280",
    "300",
    "330",
    "580",
    "590",
    "620",
    "640",
    "650"
    ]',
    '[
    {
        "name": "parcel-has-intersection-with-data-layer",
        "config": {
        "layerName": "moorland",
        "minimumIntersectionPercent": 50,
        "tolerancePercent": 1
        }
    },
    {
        "name": "applied-for-total-available-area"
    }
    ]',
    now()
),
(
   1,
    TRUE,
    TRUE,
    '2025-01-01',
    3,
    'UPL3', 
    'UPL3: Limited livestock grazing on moorland',
    'ha',
    '{
    "ratePerUnitGbp": 66
    }',
    '[
    "130",
    "240",
    "250",
    "270",
    "280",
    "300",
    "330",
    "580",
    "590",
    "620",
    "640",
    "650"
    ]',
    '[
    {
        "name": "parcel-has-intersection-with-data-layer",
        "config": {
        "layerName": "moorland",
        "minimumIntersectionPercent": 50,
        "tolerancePercent": 1
        }
    },
    {
        "name": "applied-for-total-available-area"
    }
    ]',
    now()
),
(
    1,
    FALSE,
    FALSE,
    '2025-01-01',
    3,
    'UPL4',
    'UPL4: Keep cattle and ponies on moorland supplement (minimum 30% GLU)',
    'ha',
    '{
    "ratePerUnitGbp": 7,
    "ratePerAgreementPerYearGbp": 0
    }',
    '[]',
    '[]',
    now()
),
(
    1,
    FALSE,
    FALSE,
    '2025-01-01',
    3,
    'UPL5',
    'UPL5: Keep cattle and ponies on moorland supplement (minimum 70% GLU)',
    'ha',
    '{
    "ratePerUnitGbp": 18,
    "ratePerAgreementPerYearGbp": 0
    }',
    '[]',
    '[]',
    now()
),
(
    1,
    FALSE,
    FALSE,
    '2025-01-01',
    3,
    'UPL6',
    'UPL6: Keep cattle and ponies on moorland supplement (100% GLU)',
    'ha',
    '{
    "ratePerUnitGbp": 23,
    "ratePerAgreementPerYearGbp": 0
    }',
    '[]',
    '[]',
    now()
),
(
    1,
    FALSE,
    FALSE,
    '2025-01-01',
    3,
    'UPL7',
    'UPL7: Shepherding livestock on moorland (no required stock removal period)',
    'ha',
    '{
    "ratePerUnitGbp": 33,
    "ratePerAgreementPerYearGbp": 0
    }',
    '[]',
    '[]',
    now()
),
(
    1,
    FALSE,
    FALSE,
    '2025-01-01',
    3,
    'UPL8',
    'UPL8: Shepherding livestock on moorland (remove stock for at least 4 months)',
    'ha',
    '{
    "ratePerUnitGbp": 43,
    "ratePerAgreementPerYearGbp": 0
    }',
    '[]',
    '[]',
    now()
),
(
    1,
    FALSE,
    FALSE,
    '2025-01-01',
    3,
    'UPL9',
    'UPL9: Shepherding livestock on moorland (remove stock for at least 6 months)',
    'ha',
    '{
    "ratePerUnitGbp": 45,
    "ratePerAgreementPerYearGbp": 0
    }',
    '[]',
    '[]',
    now()
),
(
    1,
    TRUE,
    FALSE,
    '2025-01-01',
    3,
    'SPM4',
    'SPM4: Keep native breeds on extensively managed habitats supplement (50-80%)',
    'ha',
    '{
    "ratePerUnitGbp": 7,
    "ratePerAgreementPerYearGbp": 0
    }',
    '[]',
    '[]',
    now()
),
(
    1,
    FALSE,
    FALSE,
    '2025-01-01',
    3,
    'SPM5',
    'SPM5: Keep native breeds on extensively managed habitats supplement (more than 80%)',
    'ha',
    '{
    "ratePerUnitGbp": 11,
    "ratePerAgreementPerYearGbp": 0
    }',
    '[]',
    '[]',
    now()
),
(
    1,
    TRUE,
    FALSE,
    '2025-01-01',
    3,
    'SAM1',
    'SAM1: Assess soil, produce a soil management plan and test soil organic matter',
    'ha',
    '{
    "ratePerUnitGbp": 6,
    "ratePerAgreementPerYearGbp": 97
    }',
    '[]',
    '[]',
    now()
),
(
    1,
    TRUE,
    FALSE,
    '2025-01-01',
    3,
    'OFM3',
    'OFM3: Organic land management – enclosed rough grazing',
    'ha',
    '{
    "ratePerUnitGbp": 97,
    "ratePerAgreementPerYearGbp": 0
    }',
    '[
    "130",
    "240",
    "250",
    "270",
    "280",
    "300",
    "330",
    "580",
    "590",
    "620",
    "640",
    "650"
    ]',
    '[]',
    now()
),
(
    1,
    TRUE,
    FALSE,
    '2025-01-01',
    3,
    'CSAM1',
    'CSAM1: Assess soil, produce a soil management plan and test soil organic matter',
    'ha',
    '{
    "ratePerUnitGbp": 6,
    "ratePerAgreementPerYearGbp": 97
    }',
    '[
    "110",
    "111",
    "112",
    "117",
    "118",
    "121",
    "130",
    "131",
    "140",
    "141",
    "142",
    "143"
    ]',
    '[]',
    now()
);