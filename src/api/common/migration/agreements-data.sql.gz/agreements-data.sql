INSERT INTO public.agreements(parcel_id, sheet_id, actions)
VALUES 
  ('7268', 'SD6743', '[{"action_code": "CMOR1", "unit": "ha", "quantity": 10}, {"action_code": "UPL1", "unit": "ha", "quantity": 50}]');
